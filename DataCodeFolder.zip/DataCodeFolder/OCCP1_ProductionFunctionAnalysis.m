load('OCCP1data.mat')

for i = 1:101
    TotalWorkers(i) = sum(SUA_OCCP1(i,:));
end
TotalWorkers=TotalWorkers';

X = SUA_Population-TotalWorkers;

X = [SUA_Population SUA_OCCP1];
%X = [X SUA_OCCP1];

result = fitlm(log(X),log(SUA_Income));
C = result.Coefficients.Estimate;
beta=sum(C(2:9));
r2=result.Rsquared.Adjusted;