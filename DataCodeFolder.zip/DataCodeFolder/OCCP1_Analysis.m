% Total Income Analysis


% OCCP1 Analysis

load('OCCP1data.mat')
results_OCCP1_Managers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,1)));
beta_Managers = results_OCCP1_Managers.Coefficients(2,1); 
beta_Managers = table2array(beta_Managers); 

results_OCCP1_Professionals = fitlm(log(SUA_Population), log(SUA_OCCP1(:,2)));
beta_Professionals = results_OCCP1_Professionals.Coefficients(2,1); 
beta_Professionals = table2array(beta_Professionals); 

results_OCCP1_TechniciansAndTradeWorkers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,3)));
beta_TechniciansAndTradeWorkers = results_OCCP1_TechniciansAndTradeWorkers.Coefficients(2,1); 
beta_TechniciansAndTradeWorkers = table2array(beta_TechniciansAndTradeWorkers); 

results_OCCP1_CommunityAndPersonalServicesWorkers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,4)));
beta_CommunityAndPersonalServicesWorkers = results_OCCP1_CommunityAndPersonalServicesWorkers.Coefficients(2,1); 
beta_CommunityAndPersonalServicesWorkers = table2array(beta_CommunityAndPersonalServicesWorkers); 

results_OCCP1_ClericalAndAdministrativeWorkers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,5)));
beta_ClericalAndAdministrativeWorkers = results_OCCP1_ClericalAndAdministrativeWorkers.Coefficients(2,1); 
beta_ClericalAndAdministrativeWorkers = table2array(beta_ClericalAndAdministrativeWorkers); 

results_OCCP1_SalesWorkers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,6)));
beta_SalesWorkers = results_OCCP1_SalesWorkers.Coefficients(2,1); 
beta_SalesWorkers = table2array(beta_SalesWorkers);

results_OCCP1_MachineryOperatorsAndDrivers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,7)));
beta_MachineryOperatorsAndDrivers = results_OCCP1_MachineryOperatorsAndDrivers.Coefficients(2,1); 
beta_MachineryOperatorsAndDrivers = table2array(beta_MachineryOperatorsAndDrivers);

results_OCCP1_Labourers = fitlm(log(SUA_Population), log(SUA_OCCP1(:,8)));
beta_Labourers = results_OCCP1_Labourers.Coefficients(2,1); 
beta_Labourers = table2array(beta_Labourers);