load('OCCP2data.mat')

for i = 1:101
    for j = 1:43
        if OCCP2_Data(i,j)==0
            OCCP2_Data(i,j)=1;
        end
    end
end

for i = 1:43
    results_OCCP2 = fitlm(log(SUA_Population), log(OCCP2_Data(:,i)));
    beta(i) = table2array(results_OCCP2.Coefficients(2,1)); 
    r2(i)=results_OCCP2.Rsquared.Adjusted; 
end

OCCP2_Names=OCCP2_Names';
beta=beta';
r2=r2';
