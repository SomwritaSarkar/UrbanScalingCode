load('USA_data.mat')

%Column 2: Population
%Column 3:7: Occupations
%Column 8:20 Industries

X1 = USA_Data(:,2); 
X2 = [USA_Data(:,2) USA_Data(:,8:20)];

result = fitlm(log(X2),log(USA_Data(:,1)));
C = result.Coefficients.Estimate;
beta=sum(C(2:15));
r2=result.Rsquared.Adjusted;