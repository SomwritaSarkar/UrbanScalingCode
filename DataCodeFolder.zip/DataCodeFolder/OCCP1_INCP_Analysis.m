load('OCCP1_INCP.mat')

% Medians of income categories

M(1)=0;
M(2)=0;
M(3)=mean(1:7799);
M(4)=mean(7800:15599);
M(5)=mean(15600:20799);
M(6)=mean(20800:25999);
M(7)=mean(26000:33799);
M(8)=mean(33800:41599);
M(9)=mean(41600:51999);
M(10)=mean(52000:64999);
M(11)=mean(65000:77999);
M(12)=mean(78000:90999);
M(13)=mean(91000:103999);
M(14)=mean(104000:155999);
M(15)=mean(156000);
M(16)=0;
M(17)=0;


% Keep extracting 17 rows and summing 3 to 15. 

Data = OCCP1_Data;

for i = 1:101
    Current_SUA = Data(1:17,:);
    Data(1:17,:) = [];
    for j = 1:17
        Current_SUA_Incomes(j,:) = Current_SUA(j,:)*M(j);
    end
    Income(i,:) = sum(Current_SUA_Incomes);
end

for i = 1:101
    ind(i) = find(strcmp(SUA_Names_OriginalOrder, SUA_Names(i)));
end

Final_Income_SUA_Names = Income(ind, :);

% Regression Total Population against Total income from each category
results_OCCP1_Managers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,1)));
beta_Managers = results_OCCP1_Managers.Coefficients(2,1); 
beta_Managers = table2array(beta_Managers); 

results_OCCP1_Professionals = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,2)));
beta_Professionals = results_OCCP1_Professionals.Coefficients(2,1); 
beta_Professionals = table2array(beta_Professionals); 

results_OCCP1_TechniciansAndTradeWorkers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,3)));
beta_TechniciansAndTradeWorkers = results_OCCP1_TechniciansAndTradeWorkers.Coefficients(2,1); 
beta_TechniciansAndTradeWorkers = table2array(beta_TechniciansAndTradeWorkers); 

results_OCCP1_CommunityAndPersonalServicesWorkers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,4)));
beta_CommunityAndPersonalServicesWorkers = results_OCCP1_CommunityAndPersonalServicesWorkers.Coefficients(2,1); 
beta_CommunityAndPersonalServicesWorkers = table2array(beta_CommunityAndPersonalServicesWorkers); 

results_OCCP1_ClericalAndAdministrativeWorkers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,5)));
beta_ClericalAndAdministrativeWorkers = results_OCCP1_ClericalAndAdministrativeWorkers.Coefficients(2,1); 
beta_ClericalAndAdministrativeWorkers = table2array(beta_ClericalAndAdministrativeWorkers); 

results_OCCP1_SalesWorkers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,6)));
beta_SalesWorkers = results_OCCP1_SalesWorkers.Coefficients(2,1); 
beta_SalesWorkers = table2array(beta_SalesWorkers);

results_OCCP1_MachineryOperatorsAndDrivers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,7)));
beta_MachineryOperatorsAndDrivers = results_OCCP1_MachineryOperatorsAndDrivers.Coefficients(2,1); 
beta_MachineryOperatorsAndDrivers = table2array(beta_MachineryOperatorsAndDrivers);

results_OCCP1_Labourers = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,8)));
beta_Labourers = results_OCCP1_Labourers.Coefficients(2,1); 
beta_Labourers = table2array(beta_Labourers);
