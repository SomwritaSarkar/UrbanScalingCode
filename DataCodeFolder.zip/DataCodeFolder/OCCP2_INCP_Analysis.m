load('OCCP2_INCP.mat')

% Medians of income categories

M(1)=0;
M(2)=0;
M(3)=mean(1:7799);
M(4)=mean(7800:15599);
M(5)=mean(15600:20799);
M(6)=mean(20800:25999);
M(7)=mean(26000:33799);
M(8)=mean(33800:41599);
M(9)=mean(41600:51999);
M(10)=mean(52000:64999);
M(11)=mean(65000:77999);
M(12)=mean(78000:90999);
M(13)=mean(91000:103999);
M(14)=mean(104000:155999);
M(15)=mean(156000);
M(16)=0;
M(17)=0;

% Keep extracting 17 rows and summing 3 to 15. 

Data = OCCP2_Data;

for i = 1:1717
    for j = 1:43
        if Data(i,j)==0
            Data(i,j)=1;
        end
    end
end

for i = 1:101
    Current_SUA = Data(1:17,:);
    Data(1:17,:) = [];
    for j = 1:17
        Current_SUA_Incomes(j,:) = Current_SUA(j,:)*M(j);
    end
    Income(i,:) = sum(Current_SUA_Incomes);
end

for i = 1:101
    ind(i) = find(strcmp(SUA_Names_OriginalOrder, SUA_Names(i)));
end

Final_Income_SUA_Names = Income(ind, :);

% Regression

for i = 1:43
    results_OCCP2 = fitlm(log(SUA_Population), log(Final_Income_SUA_Names(:,i)));
    beta(i) = table2array(results_OCCP2.Coefficients(2,1)); 
    r2(i)=results_OCCP2.Rsquared.Adjusted; 
end

OCCP2_Names=OCCP2_Names';
beta=beta';
r2=r2';


% Per worker analysis
clear
load('OCCP2_INCP.mat')
% Medians of income categories

M(1)=0;
M(2)=0;
M(3)=mean(1:7799);
M(4)=mean(7800:15599);
M(5)=mean(15600:20799);
M(6)=mean(20800:25999);
M(7)=mean(26000:33799);
M(8)=mean(33800:41599);
M(9)=mean(41600:51999);
M(10)=mean(52000:64999);
M(11)=mean(65000:77999);
M(12)=mean(78000:90999);
M(13)=mean(91000:103999);
M(14)=mean(104000:155999);
M(15)=mean(156000);
M(16)=0;
M(17)=0;

Data = OCCP2_Data;

for i = 1:1717
    for j = 1:43
        if Data(i,j)==0
            Data(i,j)=1;
        end
    end
end

for i = 1:101
    Current_SUA = Data(1:17,:);
    Data(1:17,:) = [];
    for j = 1:17
        Current_SUA_Incomes(j,:) = Current_SUA(j,:)*M(j);
    end
    Income(i,:) = sum(Current_SUA_Incomes);
end

for i = 1:101
    ind(i) = find(strcmp(SUA_Names_OriginalOrder, SUA_Names(i)));
end

Final_Income_SUA_Names = Income(ind, :);

Workers = OCCP2_Data;

for i = 1:1717
    for j = 1:43
        if Workers(i,j)==0
            Workers(i,j)=1;
        end
    end
end

for i = 1:101
    Current_SUA = Workers(1:17,:);
    Workers(1:17,:) = [];
    Current_SUA = Current_SUA(3:15,:);
    TotalWorkers(i,:) = sum(Current_SUA);
end

for i = 1:101
    ind(i) = find(strcmp(SUA_Names_OriginalOrder, SUA_Names(i)));
end

Final_TotalWorkers = TotalWorkers(ind, :);

PerWorkerIncome = Final_Income_SUA_Names./Final_TotalWorkers;



% Regression

for i = 1:43
    results_OCCP2_PerWorker = fitlm(log(SUA_Population), log(PerWorkerIncome(:,i)));
    beta_perworker(i) = table2array(results_OCCP2_PerWorker.Coefficients(2,1)); 
    r2_perworker(i)=results_OCCP2_PerWorker.Rsquared.Adjusted; 
end

OCCP2_Names=OCCP2_Names';
beta_perworker=beta_perworker';
r2_perworker=r2_perworker';

