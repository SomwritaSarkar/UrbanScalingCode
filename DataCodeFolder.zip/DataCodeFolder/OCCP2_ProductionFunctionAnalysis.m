load('OCCP2data.mat')

for i = 1:101
    TotalWorkers(i) = sum(OCCP2_Data(i,:));
end
TotalWorkers=TotalWorkers';

X = SUA_Population-TotalWorkers;

%X = [X OCCP2_Data];
X = [SUA_Population OCCP2_Data];

for i = 1:size(X,1)
    for j = 1:size(X,2) 
        if X(i,j) == 0
            X(i,j) = 1;
        end
    end
end


result = fitlm(log(X),log(SUA_Income));
C = result.Coefficients.Estimate;
beta=sum(C(2:length(C)));
r2=result.Rsquared.Adjusted;